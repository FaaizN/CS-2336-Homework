//Import scanner to take user input
import java.util.Scanner;
public class homework_one_3 {
    public static void main(String [] args) {

        //Create variables to store inputs
        double x1, y1, w1, h1;
        double x2, y2, w2, h2;

        //Ask user to input the first rectangles numbers
        System.out.print("Enter r1's center x-, y-coordinates, width, and height: ");

        //Read the user input and store into variables
        Scanner input = new Scanner(System.in);
        x1 = input.nextDouble();
        y1 = input.nextDouble();
        w1 = input.nextDouble();
        h1 = input.nextDouble();

        System.out.println();

        //Ask the user to input the second rectangles numbers
        System.out.print("Enter r2's center x-, y-coordinates, width, and height: ");

        //Read the user input and store into variables
        x2 = input.nextDouble();
        y2 = input.nextDouble();
        w2 = input.nextDouble();
        h2 = input.nextDouble();

        //System.out.printf("\nTest %.2f %.2f\n", x1, h2);

        //Create formulas for distance
        double xDistance = Math.abs(x1 - x2);
        double yDistance = Math.abs(y1 - y2);
        System.out.println();

        //If r2 is inside of r1
        if (xDistance <= (w1 - w2) / 2 && yDistance <= (h1 - h2) / 2) {
            System.out.println("r2 is inside r1");
        }
        //If r2 overlaps r1
        else if (xDistance <= (w1 + w2) / 2 && yDistance <= (h1 + h2) / 2) {
            System.out.println("r2 overlaps r1");
        }
        else { //If r2 does neither
            System.out.println("r2 does not overlap r1");
        }

    }
}
