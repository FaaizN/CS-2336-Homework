//Import Scanner to take user input
import java.util.Scanner;
public class homework_one_2 {
    public static void main(String [] args) {

        //Prompt the user for the first 9 digits of the ISBN
        System.out.print("Enter the first 9 digits of an ISBN number: ");

        //Create scanner object "input" and store user input into variable
        Scanner input = new Scanner(System.in);
        int number = input.nextInt();

        //To keep the ISBN number, create temp int to manipulate
        int temp = number;

        //Store the numbers into the variabels using modulus
        int d9 = temp % 10; temp = temp / 10;
        //System.out.printf("\nTest %d %d %d\n", number, d9, temp);
        int d8 = temp % 10; temp = temp / 10;
        int d7 = temp % 10; temp = temp / 10;
        int d6 = temp % 10; temp = temp / 10;
        int d5 = temp % 10; temp = temp / 10;
        int d4 = temp % 10; temp = temp / 10;
        int d3 = temp % 10; temp = temp / 10;
        int d2 = temp % 10; temp = temp / 10;
        int d1 = temp % 10; temp = temp / 10;

        //Calculate the checksum
        int checksum = (d1*1 + d2*2 + d3*3 + d4*4 + d5*5 + d6*6 + d7*7 + d8*8 + d9*9) % 11;
        System.out.println();

        /* If statement to determine output
            If the checksum = 10, add an X to the end of the 9 digits
            else add checksum to end of first 9 digits to complete ISBN
         */
        if (checksum == 10) {
            System.out.println("The ISBN-10 number is " + d1 + d2 + d3 + d4 + d5 + d6 + d7 + d8 + d9 + "X");
        }
        else {
            System.out.println("The ISBN-10 number is " + d1 + d2 + d3 + d4 + d5 + d6 + d7 + d8 + d9 + checksum);
        }
    }
}
