//Import scanner to take user input
import java.util.Scanner;
public class homework_one_1 {
    public static void main(String [] args) {
        //Prompt the user for a,b,c
        System.out.println("Enter a, b, c: ");

        //Create variables to store a,b,c
        double a, b, c;

        //Create scanner object "input" and store user input into variables
        Scanner input = new Scanner(System.in);
        a = input.nextDouble();
        b = input.nextDouble();
        c = input.nextDouble();

        //Create variable to calculate the discriminant
        double discriminant = Math.pow(b,2) - 4 * a * c;

        /*If statements to determine if the equation has roots or not
          If the discriminant is < 0, no real roots
          If the discriminant is = 0, there is one root
          If the discriminant is > 0, there are two roots
         */
        if (discriminant < 0) {
            System.out.println("The equation has no real roots");
        }
        else if (discriminant == 0) {
            double r1 = -b / (2 * a);
            System.out.printf("The equation has one root %.2f\n", r1);
        }
        else { //(discriminant > 0
            double r1 = (-b + Math.pow(discriminant, 0.5)) / (2 * a);
            double r2 = (-b - Math.pow(discriminant, 0.5)) / (2 * a);
            System.out.printf("The equation has two roots %.2f and %.2f\n", r1, r2);
        }
    }
}
